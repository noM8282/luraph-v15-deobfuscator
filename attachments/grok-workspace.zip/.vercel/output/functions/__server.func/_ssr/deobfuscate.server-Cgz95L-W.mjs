import { randomUUID } from "node:crypto";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { tmpdir } from "node:os";
//#region node_modules/.nitro/vite/services/ssr/assets/deobfuscate.server-Cgz95L-W.js
var HTTP_GET_RE = /(?:game\s*:\s*)?HttpGet(?:Async)?\s*\(\s*["'`](https?:\/\/[^"'`]+)["'`]/gi;
var BARE_URL_RE = /^\s*(https?:\/\/[^\s]+)\s*$/i;
var SCRIPT_KEY_RE = /script_key\s*=\s*["'`]([^"'`]+)["'`]/i;
var LURAPH_HEADER_RE = /Luraph Obfuscator v15/i;
var LURAPH_SHAPE_RE = /\[\d+\]\s*=\s*(bit32|buffer|string|table|math)\.\w+/;
function extractScriptKey(source) {
	return SCRIPT_KEY_RE.exec(source)?.[1]?.trim() || void 0;
}
function extractHttpGetUrls(source) {
	const found = [];
	const seen = /* @__PURE__ */ new Set();
	HTTP_GET_RE.lastIndex = 0;
	let m;
	while (m = HTTP_GET_RE.exec(source)) {
		const url = m[1].trim();
		if (!seen.has(url)) {
			seen.add(url);
			found.push(url);
		}
	}
	return found;
}
function looksLikeBareUrl(source) {
	const m = BARE_URL_RE.exec(source.trim());
	return m ? m[1].replace(/[),;]+$/, "") : null;
}
function isLuraphV15(source) {
	const head = source.slice(0, 800);
	if (LURAPH_HEADER_RE.test(head)) return true;
	const start = source.trimStart().slice(0, 2500);
	return start.startsWith("return setmetatable({") && LURAPH_SHAPE_RE.test(start);
}
function looksLikeLoaderStub(source) {
	if (!source.trim()) return false;
	if (isLuraphV15(source)) return false;
	if (looksLikeBareUrl(source)) return true;
	if (source.length > 12e3) return false;
	const lower = source.toLowerCase();
	const hasLoad = /loadstring\s*\(/i.test(source) || /httpget/i.test(source);
	const remote = lower.includes("luarmor.net") || lower.includes("raw.githubusercontent.com") || lower.includes("gist.githubusercontent.com") || lower.includes("github.com/");
	return hasLoad && (remote || extractHttpGetUrls(source).length > 0);
}
function classifyUrl(url) {
	const u = url.toLowerCase();
	if (u.includes("luarmor.net")) return "luarmor";
	if (u.includes("github.com") || u.includes("githubusercontent.com") || u.includes("gist.github.com")) return "github";
	return "url";
}
function rewriteSourceUrl(raw) {
	let url = raw.trim();
	try {
		url = decodeURIComponent(url);
	} catch {}
	url = url.replace(/[),.;]+$/g, "");
	const blob = url.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/(?:blob|raw)\/([^/]+)\/(.+?)(?:\?.*)?$/i);
	if (blob) return `https://raw.githubusercontent.com/${blob[1]}/${blob[2]}/${blob[3]}/${blob[4]}`;
	const gist = url.match(/^https?:\/\/gist\.github\.com\/(?:[^/]+\/)?([a-f0-9]+)(?:\.lua)?(?:\/.*)?$/i);
	if (gist) return `https://gist.githubusercontent.com/raw/${gist[1]}`;
	const gistRaw = url.match(/^https?:\/\/gist\.github\.com\/([^/]+)\/([a-f0-9]+)\/raw(?:\/(.+))?$/i);
	if (gistRaw) {
		const rest = gistRaw[3] ? `/${gistRaw[3]}` : "";
		return `https://gist.githubusercontent.com/${gistRaw[1]}/${gistRaw[2]}/raw${rest}`;
	}
	return url;
}
function luarmorAlternates(url) {
	const out = [url];
	if (!/luarmor\.net/i.test(url)) return out;
	const swapped = url.includes("/files/v3/") ? url.replace("/files/v3/", "/files/v4/") : url.includes("/files/v4/") ? url.replace("/files/v4/", "/files/v3/") : null;
	if (swapped) out.push(swapped);
	if (url.endsWith(".lua")) out.push(url.replace(/\.lua$/i, ""));
	const id = url.match(/\/loaders\/([a-f0-9]+)/i)?.[1];
	if (id) {
		out.push(`https://api.luarmor.net/files/v3/loaders/${id}.lua`);
		out.push(`https://api.luarmor.net/files/v4/loaders/${id}.lua`);
	}
	return [...new Set(out)];
}
function isHtmlPayload(body) {
	const start = body.trimStart().slice(0, 200).toLowerCase();
	return start.startsWith("<!doctype") || start.startsWith("<html") || start.includes("cannot be displayed on browser") || start.includes("<head>");
}
var FETCH_TIMEOUT_MS = 2e4;
var USER_AGENTS = [
	"Roblox/WinInet",
	"Roblox/Linux",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) syn-httpget"
];
function assertSize(bytes, where) {
	if (bytes > 8388608) throw new Error(`${where} is larger than 8 MB — too big to deobfuscate here.`);
}
async function fetchOnce(url, userAgent, extraHeaders) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
	try {
		const res = await fetch(url, {
			redirect: "follow",
			signal: ctrl.signal,
			headers: {
				Accept: "*/*",
				"User-Agent": userAgent,
				"Accept-Language": "en-US,en;q=0.9",
				...extraHeaders
			}
		});
		const buf = Buffer.from(await res.arrayBuffer());
		assertSize(buf.byteLength, url);
		return {
			status: res.status,
			body: buf.toString("latin1"),
			finalUrl: res.url || url
		};
	} finally {
		clearTimeout(timer);
	}
}
async function fetchRemote(url, scriptKey) {
	const kind = classifyUrl(url);
	const candidates = kind === "luarmor" ? luarmorAlternates(url) : [url];
	const extra = {};
	if (scriptKey) {
		extra["X-Script-Key"] = scriptKey;
		extra["script-key"] = scriptKey;
	}
	let lastError = "Could not fetch remote script.";
	for (const candidate of candidates) for (const ua of kind === "luarmor" ? USER_AGENTS : [USER_AGENTS[0]]) try {
		const result = await fetchOnce(candidate, ua, extra);
		if (result.status >= 400) {
			lastError = `${candidate} returned HTTP ${result.status}`;
			continue;
		}
		if (!result.body.trim()) {
			lastError = `${candidate} returned an empty body`;
			continue;
		}
		if (isHtmlPayload(result.body)) {
			lastError = `${candidate} returned a browser page instead of Lua`;
			continue;
		}
		const note = candidate === url ? `Fetched ${kind} (${result.body.length} bytes)` : `Fetched via ${candidate} (${result.body.length} bytes)`;
		return {
			body: result.body,
			usedUrl: result.finalUrl,
			note
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
function nextUrls(source, fallback) {
	const urls = extractHttpGetUrls(source).map(rewriteSourceUrl);
	const bare = looksLikeBareUrl(source);
	if (bare) urls.unshift(rewriteSourceUrl(bare));
	if (fallback) urls.unshift(rewriteSourceUrl(fallback));
	return [...new Set(urls)];
}
async function resolveSource(input) {
	let source = input.source ?? "";
	const explicitUrl = input.url?.trim();
	const chain = [];
	let scriptKey = input.scriptKey?.trim() || extractScriptKey(source);
	let kind = "paste";
	const startUrls = nextUrls(source, explicitUrl);
	if (!(Boolean(explicitUrl) || looksLikeLoaderStub(source)) || startUrls.length === 0) {
		if (!source.trim()) throw new Error("Paste a script, a loadstring, or a GitHub / Luarmor URL first.");
		return {
			source,
			kind,
			scriptKey,
			chain
		};
	}
	const seen = /* @__PURE__ */ new Set();
	let hops = 0;
	let currentUrls = startUrls;
	while (hops < 6 && currentUrls.length > 0) {
		const url = currentUrls.find((u) => !seen.has(u));
		if (!url) break;
		seen.add(url);
		hops += 1;
		kind = classifyUrl(url);
		const fetched = await fetchRemote(url, scriptKey);
		chain.push({
			url: fetched.usedUrl,
			kind,
			bytes: fetched.body.length,
			note: fetched.note
		});
		source = fetched.body;
		const nestedKey = extractScriptKey(source);
		if (nestedKey && !scriptKey) scriptKey = nestedKey;
		if (isLuraphV15(source) || !looksLikeLoaderStub(source)) break;
		currentUrls = nextUrls(source);
	}
	if (scriptKey && !SCRIPT_KEY_ALREADY.test(source)) source = `script_key = ${JSON.stringify(scriptKey)}\n${source}`;
	if (!source.trim()) throw new Error("The remote script was empty.");
	return {
		source,
		kind,
		scriptKey,
		chain
	};
}
var SCRIPT_KEY_ALREADY = /^\s*script_key\s*=/m;
var jobs = /* @__PURE__ */ new Map();
var JOB_TTL_MS = 18e5;
function vendorRoot() {
	return join(process.cwd(), "vendor", "deobfuscator");
}
function runtimeStatus() {
	const root = vendorRoot();
	const luau = join(root, "deobf", "bin", "luau");
	const ast = join(root, "deobf", "bin", "luau-ast");
	const deob = join(root, "deobf", "deob.py");
	return {
		python: "python3",
		hasDeob: existsSync(deob),
		hasLuau: existsSync(luau),
		hasAst: existsSync(ast),
		ready: existsSync(deob) && existsSync(luau) && existsSync(ast)
	};
}
function appendLog(job, line) {
	const text = line.endsWith("\n") ? line : `${line}\n`;
	job.log += text;
}
function snapshot(job) {
	return {
		id: job.id,
		status: job.status,
		log: job.log,
		result: job.result,
		error: job.error,
		elapsedMs: Date.now() - job.startedAt,
		filename: job.filename,
		kind: job.kind,
		chain: job.chain,
		detected: job.detected
	};
}
function gcJobs() {
	const now = Date.now();
	for (const [id, job] of jobs) if (now - job.createdAt > JOB_TTL_MS) {
		try {
			job.proc?.kill("SIGKILL");
		} catch {}
		jobs.delete(id);
	}
}
function getJob(id) {
	const job = jobs.get(id);
	return job ? snapshot(job) : null;
}
function startJob(input) {
	gcJobs();
	const timeout = Math.max(15, Math.min(input.timeout || 90, 300));
	const filename = (input.filename || "script.lua").replace(/[^\w.\-]+/g, "_");
	const job = {
		id: randomUUID(),
		status: "queued",
		log: "",
		result: null,
		error: null,
		elapsedMs: 0,
		filename,
		kind: "paste",
		chain: [],
		detected: null,
		createdAt: Date.now(),
		startedAt: Date.now()
	};
	jobs.set(job.id, job);
	runJob(job, {
		...input,
		timeout,
		filename
	});
	return snapshot(job);
}
async function runJob(job, input) {
	if (!runtimeStatus().ready) {
		job.status = "error";
		job.error = "The Luau runtime is not installed next to the deobfuscator, so jobs cannot run yet.";
		appendLog(job, "[!] luau / luau-ast / deob.py missing");
		return;
	}
	const work = mkdtempSync(join(tmpdir(), "deobf_web_"));
	try {
		job.status = "resolving";
		appendLog(job, "[*] resolving GitHub / Luarmor loadstrings…");
		const resolved = await resolveSource({
			source: input.source,
			url: input.url,
			scriptKey: input.scriptKey
		});
		job.kind = resolved.kind;
		job.chain = resolved.chain;
		for (const step of resolved.chain) appendLog(job, `[+] ${step.note}`);
		if (resolved.chain.length === 0) appendLog(job, "[*] input is already a script — skipping remote fetch");
		const inName = input.filename.toLowerCase().endsWith(".lua") ? input.filename : `${input.filename}.lua`;
		const inPath = join(work, inName);
		mkdirSync(work, { recursive: true });
		writeFileSync(inPath, resolved.source, "latin1");
		const outPath = join(work, "result.lua");
		const args = [
			join(vendorRoot(), "deobf", "deob.py"),
			inPath,
			"--timeout",
			String(input.timeout)
		];
		if (input.mode === "detect") args.push("--detect");
		else {
			if (input.plugin !== "auto") args.push("--obfuscator", input.plugin);
			if (input.noDevirt) args.push("--no-devirt");
			if (input.strings) args.push("--strings");
			args.push("-o", outPath);
		}
		job.status = "running";
		appendLog(job, input.mode === "detect" ? "[*] running detector" : `[*] running Luraph v15 pipeline${input.plugin === "auto" ? " (auto-detect)" : ` (${input.plugin})`}`);
		const { code, stdout } = await spawnDeob(job, args, input.timeout);
		if (input.mode === "detect") {
			const parts = (stdout.trim().split("\n").filter(Boolean).at(-1) ?? "").split("	");
			if (parts.length >= 3) {
				job.detected = {
					name: parts[0],
					confidence: parts[1],
					label: parts[2]
				};
				job.result = `${parts[2]}\nplugin: ${parts[0]}\nconfidence: ${parts[1]}`;
				job.status = "done";
				appendLog(job, `[+] detected ${parts[2]} (${parts[1]})`);
			} else {
				job.status = "error";
				job.error = "Detection produced no result.";
			}
			return;
		}
		if (code === 0 && existsSync(outPath)) {
			job.result = readFileSync(outPath, "latin1");
			job.status = "done";
			appendLog(job, `[+] done — ${job.result.length} bytes`);
		} else {
			job.status = "error";
			job.error = "The pipeline finished without a result. Check the log.";
		}
	} catch (err) {
		job.status = "error";
		job.error = err instanceof Error ? err.message : String(err);
		appendLog(job, `[!] ${job.error}`);
	} finally {
		try {
			rmSync(work, {
				recursive: true,
				force: true
			});
		} catch {}
	}
}
function spawnDeob(job, args, timeoutSec) {
	return new Promise((resolve, reject) => {
		const proc = spawn("python3", args, {
			cwd: vendorRoot(),
			env: {
				...process.env,
				PYTHONUNBUFFERED: "1",
				PYTHONIOENCODING: "latin-1"
			}
		});
		job.proc = proc;
		let stdout = "";
		const pump = (chunk, intoStdout) => {
			if (intoStdout) stdout += chunk;
			for (const line of chunk.split(/\r?\n/)) if (line) appendLog(job, line);
		};
		proc.stdout.setEncoding("latin1");
		proc.stderr.setEncoding("latin1");
		proc.stdout.on("data", (chunk) => pump(chunk, true));
		proc.stderr.on("data", (chunk) => pump(chunk, false));
		const killer = setTimeout(() => {
			proc.kill("SIGKILL");
		}, (timeoutSec + 20) * 1e3);
		proc.on("error", (err) => {
			clearTimeout(killer);
			reject(err);
		});
		proc.on("close", (code) => {
			clearTimeout(killer);
			resolve({
				code: code ?? 1,
				stdout
			});
		});
	});
}
function loadSampleSource() {
	return readFileSync(join(vendorRoot(), "samples", "001_vm_like_dispatch-obfuscated.lua"), "latin1");
}
//#endregion
export { getJob, loadSampleSource, runtimeStatus, startJob };
