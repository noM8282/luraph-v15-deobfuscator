import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as boolean, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as LoaderCircle, c as FileCode2, i as Play, l as Download, n as Terminal, o as Link2, r as Shield, s as Github, u as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-1nJUj2sm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium", {
	variants: { variant: {
		default: "bg-surface-2 text-muted shadow-[0_0_0_1px_rgb(255_255_255_/_0.08)]",
		ok: "bg-ok/15 text-ok",
		fail: "bg-fail/15 text-fail",
		warn: "bg-warn/15 text-warn",
		solid: "bg-primary text-primary-fg"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg shadow-[0_0_0_1px_rgb(255_255_255_/_0.08)] hover:bg-surface",
			ghost: "text-muted hover:bg-surface-2 hover:text-fg",
			outline: "bg-transparent text-fg shadow-[0_0_0_1px_rgb(255_255_255_/_0.10)] hover:bg-surface-2"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md bg-surface-2 px-3 text-sm text-fg shadow-[0_0_0_1px_rgb(255_255_255_/_0.08)] transition-[box-shadow] duration-150 placeholder:text-subtle focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_rgb(215_221_216_/_0.55)] disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
	ref,
	className: cn("text-xs font-medium tracking-wide text-muted", className),
	...props
}));
Label.displayName = "Label";
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-10 shrink-0 cursor-pointer items-center rounded-full shadow-[0_0_0_1px_rgb(255_255_255_/_0.10)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:cursor-not-allowed disabled:opacity-40 data-[state=checked]:bg-primary data-[state=unchecked]:bg-surface-2", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block size-5 translate-x-0.5 rounded-full bg-fg shadow-sm transition-transform data-[state=checked]:translate-x-[18px] data-[state=checked]:bg-primary-fg") })
}));
Switch.displayName = Switch$1.displayName;
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-11 items-center justify-start gap-1 rounded-lg bg-surface-2 p-1 text-muted shadow-[0_0_0_1px_rgb(255_255_255_/_0.06)]", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-md px-3 text-sm font-medium whitespace-nowrap transition-[background-color,color] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 data-[state=active]:bg-surface data-[state=active]:text-fg data-[state=inactive]:hover:text-fg", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-3 focus-visible:outline-none", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-48 w-full rounded-md bg-surface-2 px-3 py-3 text-sm leading-relaxed text-fg shadow-[0_0_0_1px_rgb(255_255_255_/_0.08)] transition-[box-shadow] duration-150 placeholder:text-subtle focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_rgb(215_221_216_/_0.55)] disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var pluginSchema = _enum([
	"auto",
	"luraph_v15",
	"ironbrew1",
	"generic"
]);
var modeSchema = _enum(["deobfuscate", "detect"]);
var startSchema = object({
	source: string().max(8e6),
	url: string().max(2e3).optional(),
	scriptKey: string().max(500).optional(),
	filename: string().max(180).optional(),
	plugin: pluginSchema,
	mode: modeSchema,
	noDevirt: boolean(),
	strings: boolean(),
	timeout: number().int().min(15).max(300)
});
var getRuntimeStatusFn = createServerFn({ method: "GET" }).handler(createSsrRpc("0bd2ce0986522630578583d2cdda7f20d2741f26880a27b3cfa539547849b982"));
var loadSampleFn = createServerFn({ method: "GET" }).handler(createSsrRpc("1016e52461ece7dc837edf48db688ad02441fc1c9e2ab56c3429f11f2a81db87"));
var startDeobfuscateFn = createServerFn({ method: "POST" }).validator(startSchema).handler(createSsrRpc("7219bfabef859060bb3902c5bd04e0155dfa1610091a18ff6eb639e8b9ac3eaf"));
var pollJobFn = createServerFn({ method: "POST" }).validator(object({ id: string().min(1) })).handler(createSsrRpc("18145716de9037a40291be11dced7f5465902ff0533b01d04c8e848dafd7c5fd"));
var PLUGINS = [
	{
		id: "luraph_v15",
		label: "Luraph v15"
	},
	{
		id: "auto",
		label: "Auto"
	},
	{
		id: "ironbrew1",
		label: "IronBrew1"
	},
	{
		id: "generic",
		label: "Trace"
	}
];
function downloadName(filename) {
	return filename.replace(/\.(luau?|txt)$/i, "") + ".deobf.lua";
}
function formatElapsed(ms) {
	return `${(Math.max(0, ms) / 1e3).toFixed(1)}s`;
}
function logClass(line) {
	if (line.startsWith("[+]")) return "text-ok";
	if (line.startsWith("[!]")) return "text-fail";
	if (line.startsWith("[*]")) return "text-warn";
	return "text-muted";
}
function DeobfStudio() {
	const [inputTab, setInputTab] = (0, import_react.useState)("script");
	const [source, setSource] = (0, import_react.useState)("");
	const [url, setUrl] = (0, import_react.useState)("");
	const [scriptKey, setScriptKey] = (0, import_react.useState)("");
	const [filename, setFilename] = (0, import_react.useState)("script.lua");
	const [plugin, setPlugin] = (0, import_react.useState)("luraph_v15");
	const [mode, setMode] = (0, import_react.useState)("deobfuscate");
	const [noDevirt, setNoDevirt] = (0, import_react.useState)(false);
	const [dumpStrings, setDumpStrings] = (0, import_react.useState)(false);
	const [timeout, setTimeoutSec] = (0, import_react.useState)(90);
	const [job, setJob] = (0, import_react.useState)(null);
	const [view, setView] = (0, import_react.useState)("log");
	const [drag, setDrag] = (0, import_react.useState)(false);
	const [runtimeReady, setRuntimeReady] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	const logRef = (0, import_react.useRef)(null);
	const pollRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		getRuntimeStatusFn().then((s) => setRuntimeReady(s.ready)).catch(() => setRuntimeReady(false));
	}, []);
	(0, import_react.useEffect)(() => {
		if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
	}, [job?.log]);
	const running = job?.status === "queued" || job?.status === "resolving" || job?.status === "running";
	const stopPoll = () => {
		if (pollRef.current) {
			window.clearInterval(pollRef.current);
			pollRef.current = null;
		}
	};
	(0, import_react.useEffect)(() => () => stopPoll(), []);
	const watch = (id) => {
		stopPoll();
		pollRef.current = window.setInterval(() => {
			pollJobFn({ data: { id } }).then((next) => {
				setJob(next);
				if (next.status === "done") {
					setView("result");
					stopPoll();
				} else if (next.status === "error") {
					setView("log");
					stopPoll();
				}
			}).catch((err) => {
				stopPoll();
				toast.error(err instanceof Error ? err.message : "Polling failed");
			});
		}, 600);
	};
	const readFile = async (file) => {
		const buf = await file.arrayBuffer();
		setSource(new TextDecoder("latin1").decode(buf));
		setFilename(file.name || "script.lua");
		setInputTab("script");
	};
	const onDrop = async (e) => {
		e.preventDefault();
		setDrag(false);
		const file = e.dataTransfer.files[0];
		if (file) await readFile(file);
	};
	const run = (0, import_react.useCallback)(async () => {
		const payloadUrl = inputTab === "loadstring" ? url.trim() : void 0;
		if (!source.trim() && !payloadUrl) {
			toast.error("Paste a script, drop a file, or enter a loadstring URL.");
			return;
		}
		setView("log");
		try {
			const started = await startDeobfuscateFn({ data: {
				source,
				url: payloadUrl || void 0,
				scriptKey: scriptKey.trim() || void 0,
				filename,
				plugin,
				mode,
				noDevirt,
				strings: dumpStrings,
				timeout
			} });
			setJob(started);
			watch(started.id);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not start the job");
		}
	}, [
		dumpStrings,
		filename,
		inputTab,
		mode,
		noDevirt,
		plugin,
		scriptKey,
		source,
		timeout,
		url
	]);
	const loadSample = async () => {
		try {
			const sample = await loadSampleFn();
			setSource(sample.source);
			setFilename(sample.filename);
			setInputTab("script");
			setPlugin("luraph_v15");
			setMode("deobfuscate");
			toast.success("Loaded the Luraph v15 sample");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load sample");
		}
	};
	const copyResult = async () => {
		if (!job?.result) return;
		await navigator.clipboard.writeText(job.result);
		toast.success("Copied decompiled code");
	};
	const downloadResult = () => {
		if (!job?.result) return;
		const blob = new Blob([job.result], { type: "text/plain;charset=utf-8" });
		const href = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = href;
		a.download = downloadName(job.filename || filename);
		a.click();
		URL.revokeObjectURL(href);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border px-4 py-5 sm:px-6 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-[1400px] flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs tracking-[0.22em] text-muted uppercase",
								children: "Deobf"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 text-2xl font-medium tracking-tight text-fg sm:text-3xl",
								children: "Luraph v15 decompiler"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
								children: "Paste protected Luau, or a GitHub / Luarmor loadstring. The pipeline fetches the remote script, runs the Luraph v15 lifter, and lets you download the decompiled code."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Luraph v15" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "GitHub loadstring" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Luarmor fetch" })
						]
					})]
				})
			}),
			runtimeReady === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border bg-fail/10 px-4 py-3 text-sm text-fail sm:px-6 lg:px-8",
				children: "The Luau runtime is missing, so decompile jobs cannot start."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid w-full max-w-[1400px] flex-1 grid-cols-1 gap-4 p-4 lg:grid-cols-2 lg:gap-6 lg:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-0 flex-col rounded-xl bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255_/_0.08)] sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium tracking-wide text-fg",
								children: "Input"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => void loadSample(),
								type: "button",
								children: "Load v15 sample"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
							value: inputTab,
							onValueChange: setInputTab,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
									className: "w-full sm:w-auto",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
											value: "script",
											className: "flex-1 sm:flex-none",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode2, { className: "size-3.5" }), "Script"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
											value: "loadstring",
											className: "flex-1 sm:flex-none",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-3.5" }), "Loadstring"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
											value: "file",
											className: "flex-1 sm:flex-none",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Terminal, { className: "size-3.5" }), "File"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
									value: "script",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: source,
										onChange: (e) => setSource(e.target.value),
										onDragOver: (e) => {
											e.preventDefault();
											setDrag(true);
										},
										onDragLeave: () => setDrag(false),
										onDrop: (e) => void onDrop(e),
										spellCheck: false,
										placeholder: `-- This file was protected using Luraph Obfuscator v15
-- or paste a loadstring(game:HttpGet("…"))() stub`,
										className: cn("min-h-64 font-mono text-[13px]", drag && "shadow-[0_0_0_1px_rgb(215_221_216_/_0.55)]")
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
									value: "loadstring",
									className: "space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "ls-url",
													children: "GitHub or Luarmor URL"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Github, { className: "pointer-events-none absolute top-3.5 left-3 size-4 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														id: "ls-url",
														value: url,
														onChange: (e) => setUrl(e.target.value),
														placeholder: "https://api.luarmor.net/files/v3/loaders/….lua",
														className: "pl-10 font-mono text-[13px]"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-xs leading-relaxed text-subtle",
													children: [
														"Accepts raw GitHub / gist URLs, github.com blob links, Luarmor v3/v4 loaders, or a full ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono text-muted",
															children: "loadstring(game:HttpGet(…))()"
														}),
														" ",
														"pasted below."
													]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "ls-key",
												children: "Luarmor script_key (optional)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "ls-key",
												value: scriptKey,
												onChange: (e) => setScriptKey(e.target.value),
												placeholder: "script_key if the loader requires one",
												className: "font-mono text-[13px]"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											value: source,
											onChange: (e) => setSource(e.target.value),
											spellCheck: false,
											placeholder: "script_key = \"KEY\"\nloadstring(game:HttpGet(\"https://api.luarmor.net/files/v3/loaders/….lua\"))()",
											className: "min-h-40 font-mono text-[13px]"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
									value: "file",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => fileRef.current?.click(),
										onDragOver: (e) => {
											e.preventDefault();
											setDrag(true);
										},
										onDragLeave: () => setDrag(false),
										onDrop: (e) => void onDrop(e),
										className: cn("flex min-h-48 w-full flex-col items-center justify-center rounded-lg bg-surface-2 px-4 text-center shadow-[0_0_0_1px_rgb(255_255_255_/_0.08)] transition-[box-shadow] duration-150", drag && "shadow-[0_0_0_1px_rgb(215_221_216_/_0.55)]"),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode2, { className: "mb-3 size-6 text-muted" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-fg",
												children: "Drop a .lua / .luau file"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-xs text-subtle",
												children: ["or click to choose · ", filename]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: fileRef,
										type: "file",
										accept: ".lua,.luau,.txt,.lua.txt",
										hidden: true,
										onChange: (e) => {
											const file = e.target.files?.[0];
											if (file) readFile(file);
										}
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Plugin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1.5",
										children: PLUGINS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setPlugin(p.id),
											className: cn("h-10 rounded-md px-3 text-sm font-medium transition-colors duration-150", plugin === p.id ? "bg-primary text-primary-fg" : "bg-surface-2 text-muted shadow-[0_0_0_1px_rgb(255_255_255_/_0.08)] hover:text-fg"),
											children: p.label
										}, p.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-x-5 gap-y-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex min-h-11 items-center gap-2.5 text-sm text-fg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
												checked: mode === "detect",
												onCheckedChange: (on) => setMode(on ? "detect" : "deobfuscate")
											}), "Detect only"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex min-h-11 items-center gap-2.5 text-sm text-fg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
												checked: noDevirt,
												onCheckedChange: setNoDevirt,
												disabled: mode === "detect"
											}), "Fast trace"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex min-h-11 items-center gap-2.5 text-sm text-fg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
												checked: dumpStrings,
												onCheckedChange: setDumpStrings,
												disabled: mode === "detect"
											}), "Dump strings"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex min-h-11 items-center gap-2 text-sm text-fg",
											children: [
												"Timeout",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "number",
													min: 15,
													max: 300,
													value: timeout,
													onChange: (e) => setTimeoutSec(Number(e.target.value) || 90),
													className: "h-10 w-20"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-subtle",
													children: "s"
												})
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "lg",
									className: "w-full",
									onClick: () => void run(),
									disabled: running || runtimeReady === false,
									children: [running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5" }), running ? "Decompiling…" : mode === "detect" ? "Detect obfuscator" : "Decompile"]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-0 flex-col rounded-xl bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255_/_0.08)] sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-medium tracking-wide text-fg",
										children: "Output"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { job }),
									job ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-subtle tabular-nums",
										children: formatElapsed(job.elapsedMs)
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "secondary",
									size: "sm",
									onClick: () => void copyResult(),
									disabled: !job?.result,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Copy"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "sm",
									onClick: downloadResult,
									disabled: !job?.result || job.status !== "done",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Download"]
								})]
							})]
						}),
						job?.chain?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 flex flex-wrap gap-1.5",
							children: job.chain.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								className: "max-w-full truncate font-mono normal-case",
								children: [
									step.kind,
									": ",
									step.url.replace(/^https?:\/\//, "")
								]
							}, step.url))
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex gap-1 rounded-lg bg-surface-2 p-1 shadow-[0_0_0_1px_rgb(255_255_255_/_0.06)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setView("log"),
								className: cn("h-9 flex-1 rounded-md text-sm font-medium", view === "log" ? "bg-surface text-fg" : "text-muted hover:text-fg"),
								children: "Log"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setView("result"),
								className: cn("h-9 flex-1 rounded-md text-sm font-medium", view === "result" ? "bg-surface text-fg" : "text-muted hover:text-fg"),
								children: "Decompiled"
							})]
						}),
						view === "log" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							ref: logRef,
							className: "min-h-72 flex-1 overflow-auto rounded-lg bg-bg p-3 font-mono text-[12px] leading-5 text-muted shadow-[0_0_0_1px_rgb(255_255_255_/_0.06)] sm:min-h-96",
							children: job?.log ? job.log.split("\n").map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("block whitespace-pre-wrap", logClass(line)),
								children: line
							}, i)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-subtle",
								children: "Pipeline output lands here. Fetching a Luarmor or GitHub loadstring is the first step; then the Luraph v15 VM is traced and lifted."
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "min-h-72 flex-1 overflow-auto rounded-lg bg-bg p-3 font-mono text-[12px] leading-5 text-fg shadow-[0_0_0_1px_rgb(255_255_255_/_0.06)] sm:min-h-96",
							children: job?.result ? job.result : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-subtle",
								children: job?.error ?? "No decompiled output yet. Run a job, then download from here."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 flex items-start gap-2 text-xs leading-relaxed text-subtle",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "mt-0.5 size-3.5 shrink-0" }), "Scripts run inside a fake Roblox environment used only to lift Luraph bytecode. Remote loaders are fetched server-side so you get the protected payload, not the stub."]
						})
					]
				})]
			})
		]
	});
}
function StatusBadge({ job }) {
	if (!job) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "idle" });
	if (job.status === "done") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "ok",
		children: "done"
	});
	if (job.status === "error") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "fail",
		children: "failed"
	});
	if (job.status === "resolving") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "warn",
		children: "fetching"
	});
	if (job.status === "running" || job.status === "queued") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "warn",
		children: job.status
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: job.status });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeobfStudio, {});
}
//#endregion
export { Home as component };
