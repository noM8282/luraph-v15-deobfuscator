import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as boolean, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/deobfuscate.functions-BO0Ln308.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var pluginSchema = _enum([
	"auto",
	"luraph_v15",
	"ironbrew1",
	"generic"
]);
var modeSchema = _enum(["deobfuscate", "detect"]);
var startSchema = object({
	source: string().max(8e6),
	url: string().max(2e3).optional(),
	scriptKey: string().max(500).optional(),
	filename: string().max(180).optional(),
	plugin: pluginSchema,
	mode: modeSchema,
	noDevirt: boolean(),
	strings: boolean(),
	timeout: number().int().min(15).max(300)
});
var getRuntimeStatusFn_createServerFn_handler = createServerRpc({
	id: "0bd2ce0986522630578583d2cdda7f20d2741f26880a27b3cfa539547849b982",
	name: "getRuntimeStatusFn",
	filename: "src/lib/deobfuscate.functions.ts"
}, (opts) => getRuntimeStatusFn.__executeServer(opts));
var getRuntimeStatusFn = createServerFn({ method: "GET" }).handler(getRuntimeStatusFn_createServerFn_handler, async () => {
	const { runtimeStatus } = await import("./deobfuscate.server-Cgz95L-W.mjs");
	return runtimeStatus();
});
var loadSampleFn_createServerFn_handler = createServerRpc({
	id: "1016e52461ece7dc837edf48db688ad02441fc1c9e2ab56c3429f11f2a81db87",
	name: "loadSampleFn",
	filename: "src/lib/deobfuscate.functions.ts"
}, (opts) => loadSampleFn.__executeServer(opts));
var loadSampleFn = createServerFn({ method: "GET" }).handler(loadSampleFn_createServerFn_handler, async () => {
	const { loadSampleSource } = await import("./deobfuscate.server-Cgz95L-W.mjs");
	return {
		filename: "001_vm_like_dispatch-obfuscated.lua",
		source: loadSampleSource()
	};
});
var startDeobfuscateFn_createServerFn_handler = createServerRpc({
	id: "7219bfabef859060bb3902c5bd04e0155dfa1610091a18ff6eb639e8b9ac3eaf",
	name: "startDeobfuscateFn",
	filename: "src/lib/deobfuscate.functions.ts"
}, (opts) => startDeobfuscateFn.__executeServer(opts));
var startDeobfuscateFn = createServerFn({ method: "POST" }).validator(startSchema).handler(startDeobfuscateFn_createServerFn_handler, async ({ data }) => {
	const { startJob } = await import("./deobfuscate.server-Cgz95L-W.mjs");
	return startJob(data);
});
var pollJobFn_createServerFn_handler = createServerRpc({
	id: "18145716de9037a40291be11dced7f5465902ff0533b01d04c8e848dafd7c5fd",
	name: "pollJobFn",
	filename: "src/lib/deobfuscate.functions.ts"
}, (opts) => pollJobFn.__executeServer(opts));
var pollJobFn = createServerFn({ method: "POST" }).validator(object({ id: string().min(1) })).handler(pollJobFn_createServerFn_handler, async ({ data }) => {
	const { getJob } = await import("./deobfuscate.server-Cgz95L-W.mjs");
	const job = getJob(data.id);
	if (!job) throw new Error("Job not found. It may have expired.");
	return job;
});
//#endregion
export { getRuntimeStatusFn_createServerFn_handler, loadSampleFn_createServerFn_handler, pollJobFn_createServerFn_handler, startDeobfuscateFn_createServerFn_handler };
