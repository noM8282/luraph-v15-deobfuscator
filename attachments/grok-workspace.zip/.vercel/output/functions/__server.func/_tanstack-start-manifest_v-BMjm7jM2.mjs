//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BMjm7jM2.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DNE680Lt.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DNE680Lt.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-GHqNAoZ7.js"]
	}
} });
//#endregion
export { tsrStartManifest };
